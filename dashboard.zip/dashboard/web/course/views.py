from django.shortcuts import render,redirect
import mysql.connector as sql
from datetime import datetime
un=''
pwd=''
# Create your views here.
def loginaction(request):
    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="oviya@123",database='db2')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="username":
                un=value
            if key=="password":
                pwd=value
        
        c="select * from users where username='{}' and password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'error.html')
        else:
            return redirect('dashboard')

    return render(request,'login_page.html')




def dashboard(request):
    return render(request, 'dashboard.html')

def courses_dashboard(request):
    return render(request, 'courses_dashboard.html')

def view_courses(request):
    m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
    cursor = m.cursor()
    cursor.execute("SELECT course_id, course_name, course_details FROM course WHERE is_active = TRUE AND is_deleted = FALSE")
    courses = cursor.fetchall()
    course_list = []
    for course in courses:
        course_id = course[0]
        syllabus_cursor = m.cursor()
        syllabus_cursor.execute("SELECT syllabus_name, syllabus_desc FROM syllabus WHERE course_id = %s", (course_id,))
        syllabus = syllabus_cursor.fetchall()
        
        project_cursor = m.cursor()
        project_cursor.execute("SELECT project_name, project_details FROM projects WHERE course_id = %s", (course_id,))
        projects = project_cursor.fetchall()
        
        course_list.append({
            'course_id': course[0],
            'course_name': course[1],
            'course_details': course[2],
            'syllabus': syllabus,
            'projects': projects
        })
    return render(request, 'view_courses.html', {'courses': course_list})

def add_course(request):
    if request.method == "POST":
        course_name = request.POST['course_name']
        course_details = request.POST['course_details']
        
        # Get the current user's username
        
        update_by = un
        
        # Generate a unique course_id
        m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
        cursor = m.cursor()
        cursor.execute("SELECT MAX(course_id) FROM course")
        max_course_id = cursor.fetchone()[0]
        if max_course_id is None:
            course_id = 'course_101'
        else:
            _, num = max_course_id.split('_')
            num = int(num) + 1
            course_id = f'course_{num}'
        
        # Generate a unique course_sk_id
        cursor.execute("SELECT MAX(course_sk_id) FROM course")
        max_course_sk_id = cursor.fetchone()[0]
        if max_course_sk_id is None:
            course_sk_id = '101'
        else:
            course_sk_id = str(int(max_course_sk_id) + 1)
        
        cursor.execute("INSERT INTO course (course_id, course_sk_id, Course_Name, Course_Details, update_by, last_updated_dttm, rec_eff_from_dttm, rec_eff_to_dttm, is_active, is_deleted) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", 
                       (course_id, course_sk_id, course_name, course_details, update_by, datetime.now(), datetime.now(), '9999-12-31 00:00:00', True, False))
        m.commit()
        return redirect('view_courses')
    return render(request, 'add_course.html')


def edit_course(request, course_id):
    if request.method == "POST":
        course_name = request.POST['course_name']
        course_details = request.POST['course_details']
        
        # Get the current user's username
        update_by = un
        
        # Get the current date and time
        current_dttm = datetime.now()
        
        # Get the old course record
        m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
        cursor = m.cursor()
        cursor.execute("SELECT * FROM course WHERE course_id = %s", (course_id,))
        old_course = cursor.fetchone()
        
        # Update the old course record to set is_active to 0
        cursor.execute("UPDATE course SET is_active = 0, last_updated_dttm = %s WHERE course_id = %s", (current_dttm, course_id))
        m.commit()
        
        # Generate a new course_id and course_sk_id
        cursor.execute("SELECT MAX(course_sk_id) FROM course")
        result = cursor.fetchone()
        if result is None:
            max_sk_id = 0
        else:
            max_sk_id = result[0]
        new_sk_id = max_sk_id + 1
        new_course_id = f"course_{new_sk_id}"
        
        # Create a new course record with the updated values
        cursor.execute("INSERT INTO course (course_id, course_sk_id, Course_Name, Course_Details, update_by, last_updated_dttm, rec_eff_from_dttm, rec_eff_to_dttm, is_active, is_deleted) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", 
                       (new_course_id, new_sk_id, course_name, course_details, update_by, current_dttm, current_dttm, '9999-12-31 00:00:00', True, False))
        m.commit()
        
        return redirect('view_courses')
    
    else:
        m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
        cursor = m.cursor()
        cursor.execute("SELECT course_name, course_details FROM course WHERE course_id = %s", (course_id,))
        course = cursor.fetchone()
        return render(request, 'edit_course.html', {'course_id': course_id, 'course_name': course[0], 'course_details': course[1]})




def delete_course(request, course_id):
    m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
    cursor = m.cursor()
    cursor.execute("UPDATE course SET is_active = FALSE, is_deleted = TRUE WHERE course_id = %s", (course_id,))
    m.commit()
    return redirect('view_courses')


def view_syllabus(request, course_id):
    m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
    cursor = m.cursor()
    cursor.execute("SELECT syllabus_name, syllabus_desc FROM syllabus WHERE course_id = %s", (course_id,))
    syllabus = cursor.fetchall()
    return render(request, 'view_syllabus.html', {'syllabus': syllabus})

def view_projects(request, course_id):
    m = sql.connect(host="localhost", user="root", passwd="oviya@123", database='db3')
    cursor = m.cursor()
    cursor.execute("SELECT project_name, project_details FROM projects WHERE course_id = %s", (course_id,))
    projects = cursor.fetchall()
    return render(request, 'view_projects.html', {'projects': projects})

